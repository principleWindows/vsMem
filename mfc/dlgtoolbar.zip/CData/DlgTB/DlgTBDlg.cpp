// DlgTBDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DlgTB.h"
#include "DlgTBDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();


// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgTBDlg dialog

CDlgTBDlg::CDlgTBDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgTBDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgTBDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDlgTBDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgTBDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDlgTBDlg, CDialog)
	//{{AFX_MSG_MAP(CDlgTBDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_COMMAND(ID_IDMA, OnIdma)
	ON_COMMAND(IDM_B, OnB)
	ON_COMMAND(IDM_D, OnD)
	ON_COMMAND(IDM_C, OnC)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgTBDlg message handlers

BOOL CDlgTBDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	if(!m_wndToolBar.Create(this) || !m_wndToolBar.LoadToolBar(IDR_TOOLBAR1))
{
	TRACE0("Failed to Create Dialog Toolbar\n");
	EndDialog(IDCANCEL);
}

	butD = TRUE;
CRect	rcClientOld; // Old Client Rect
CRect	rcClientNew; // New Client Rect with Tollbar Added
GetClientRect(rcClientOld); // Retrive the Old Client WindowSize
// Called to reposition and resize control bars in the client area of a window
// The reposQuery FLAG does not really traw the Toolbar.  It only does the calculations.
// And puts the new ClientRect values in rcClientNew so we can do the rest of the Math.
RepositionBars(AFX_IDW_CONTROLBAR_FIRST,AFX_IDW_CONTROLBAR_LAST,0,reposQuery,rcClientNew);

// All of the Child Windows (Controls) now need to be moved so the Tollbar does not cover them up.
// Offest to move all child controls after adding Tollbar
CPoint ptOffset(rcClientNew.left-rcClientOld.left,
		rcClientNew.top-rcClientOld.top);

CRect	rcChild;
CWnd*	pwndChild = GetWindow(GW_CHILD);  //Handle to the Dialog Controls
while(pwndChild) // Cycle through all child controls
{
	pwndChild->GetWindowRect(rcChild); //  Get the child control RECT
	ScreenToClient(rcChild); 
	rcChild.OffsetRect(ptOffset); // Changes the Child Rect by the values of the claculated offset
	pwndChild->MoveWindow(rcChild,FALSE); // Move the Child Control
	pwndChild = pwndChild->GetNextWindow();
}

CRect	rcWindow;
GetWindowRect(rcWindow); // Get the RECT of the Dialog
rcWindow.right += rcClientOld.Width() - rcClientNew.Width(); // Increase width to new Client Width
rcWindow.bottom += rcClientOld.Height() - rcClientNew.Height(); // Increase height to new Client Height
MoveWindow(rcWindow,FALSE); // Redraw Window

// Now we REALLY Redraw the Toolbar
RepositionBars(AFX_IDW_CONTROLBAR_FIRST,AFX_IDW_CONTROLBAR_LAST,0);



	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDlgTBDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDlgTBDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDlgTBDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CDlgTBDlg::OnIdma() 
{
	AfxMessageBox("Button A Pressed - Button D Disabled");
	CToolBar* pBar = &m_wndToolBar;
	UINT iButtonID;
	UINT iButtonStyle; 
	int  iButtonImage;
	pBar->GetButtonInfo(3, iButtonID, iButtonStyle,iButtonImage);
	iButtonStyle = TBBS_DISABLED;
	pBar->SetButtonInfo(3, iButtonID, iButtonStyle,iButtonImage);

}


void CDlgTBDlg::OnB() 
{
	AfxMessageBox("Button B Pressed - Button D Enabled");
	CToolBar* pBar = &m_wndToolBar;
	UINT iButtonID;
	UINT iButtonStyle; 
	int  iButtonImage;
	pBar->GetButtonInfo(3, iButtonID, iButtonStyle,iButtonImage);
	iButtonStyle = 0;
	pBar->SetButtonInfo(3, iButtonID, iButtonStyle,iButtonImage);
	
}

void CDlgTBDlg::OnD() 
{
	// TODO: Add your command handler code here
	AfxMessageBox("Button D Pressed");
	
}

void CDlgTBDlg::OnC() 
{
	AfxMessageBox("Button C Pressed");
	
}
